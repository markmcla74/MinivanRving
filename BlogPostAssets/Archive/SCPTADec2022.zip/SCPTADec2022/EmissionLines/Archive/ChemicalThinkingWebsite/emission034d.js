(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"emission_atlas_", frames: [[1042,1438,766,100],[1042,1336,766,100],[0,1486,1034,138],[767,1846,763,100],[0,1626,765,100],[1044,240,451,299],[0,999,1039,243],[0,1244,1040,240],[0,760,1094,237],[1044,0,920,238],[1497,480,366,238],[1497,240,368,238],[0,508,1040,250],[0,0,1042,252],[0,254,1042,252],[1041,1030,766,100],[1041,1132,766,100],[1042,1234,766,100],[1096,928,767,100],[0,1932,763,100],[767,1642,765,100],[1096,720,767,102],[1096,824,765,102],[1036,1540,766,100],[0,1830,765,100],[0,1728,765,100],[767,1744,765,100]]},
		{name:"emission_atlas_2", frames: [[0,0,767,99],[0,774,406,44],[845,232,51,67],[947,69,51,67],[947,0,51,67],[767,296,51,67],[767,434,51,67],[820,301,51,67],[767,365,51,67],[926,301,51,67],[951,232,51,67],[873,301,51,67],[769,0,46,140],[817,0,46,140],[820,370,51,67],[873,370,51,67],[898,232,51,67],[926,370,51,67],[0,699,362,73],[364,699,362,73],[820,439,54,54],[0,202,763,99],[865,0,80,76],[767,142,78,75],[847,155,78,75],[927,155,78,75],[865,78,80,75],[765,219,78,75],[0,303,765,98],[0,602,765,95],[0,403,765,98],[0,101,765,99],[0,503,765,97]]}
];


// symbols:



(lib.Al = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Ar = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.B = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Be = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.C = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Ca = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1 = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_2 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_41 = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_42 = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_43 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_44 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_45 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_46 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_47 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_48 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_49 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_50 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_51 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_52 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_53 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_54 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_55 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_56 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_57 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_58 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_59 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_60 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_61 = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_62 = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_63 = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_64 = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_73 = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_74 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_75 = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_76 = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Cl = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.F = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.H = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.He = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.image13 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.image18 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.image22 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.image25 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.image29 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.image9 = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.K = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Li = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Mg = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.N = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.Na = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Ne = function() {
	this.initialize(ss["emission_atlas_2"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.Ni = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.O = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.P = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Pb = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.S = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Si = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Sr = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Zn = function() {
	this.initialize(ss["emission_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.yellowHandle_sb = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_74();
	this.instance.parent = this;
	this.instance.setTransform(-3.45,-3.45,0.1286,0.1286);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.yellowHandle_sb, new cjs.Rectangle(-3.4,-3.4,6.9,6.9), null);


(lib.transparent = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_73();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.transparent, new cjs.Rectangle(0,0,375,90.2), null);


(lib.ruler_sb = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// labels
	this.instance = new lib.CachedTexturedBitmap_58();
	this.instance.parent = this;
	this.instance.setTransform(211.2,-32,0.2125,0.2125);

	this.instance_1 = new lib.CachedTexturedBitmap_57();
	this.instance_1.parent = this;
	this.instance_1.setTransform(196.3,-32,0.2125,0.2125);

	this.instance_2 = new lib.CachedTexturedBitmap_56();
	this.instance_2.parent = this;
	this.instance_2.setTransform(180.4,-32,0.2125,0.2125);

	this.instance_3 = new lib.CachedTexturedBitmap_55();
	this.instance_3.parent = this;
	this.instance_3.setTransform(165.4,-32,0.2125,0.2125);

	this.instance_4 = new lib.CachedTexturedBitmap_54();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-1.9,-39.7,0.2125,0.2125);

	this.instance_5 = new lib.CachedTexturedBitmap_53();
	this.instance_5.parent = this;
	this.instance_5.setTransform(223.35,-39.7,0.2125,0.2125);

	this.instance_6 = new lib.CachedTexturedBitmap_52();
	this.instance_6.parent = this;
	this.instance_6.setTransform(71.5,-32,0.2125,0.2125);

	this.instance_7 = new lib.CachedTexturedBitmap_51();
	this.instance_7.parent = this;
	this.instance_7.setTransform(87.5,-32,0.2125,0.2125);

	this.instance_8 = new lib.CachedTexturedBitmap_50();
	this.instance_8.parent = this;
	this.instance_8.setTransform(56.3,-32,0.2125,0.2125);

	this.instance_9 = new lib.CachedTexturedBitmap_49();
	this.instance_9.parent = this;
	this.instance_9.setTransform(118.25,-32,0.2125,0.2125);

	this.instance_10 = new lib.CachedTexturedBitmap_48();
	this.instance_10.parent = this;
	this.instance_10.setTransform(40.7,-32,0.2125,0.2125);

	this.instance_11 = new lib.CachedTexturedBitmap_47();
	this.instance_11.parent = this;
	this.instance_11.setTransform(134.1,-32,0.2125,0.2125);

	this.instance_12 = new lib.CachedTexturedBitmap_46();
	this.instance_12.parent = this;
	this.instance_12.setTransform(25.55,-32,0.2125,0.2125);

	this.instance_13 = new lib.CachedTexturedBitmap_45();
	this.instance_13.parent = this;
	this.instance_13.setTransform(150.1,-32,0.2125,0.2125);

	this.instance_14 = new lib.CachedTexturedBitmap_44();
	this.instance_14.parent = this;
	this.instance_14.setTransform(10,-32,0.2125,0.2125);

	this.instance_15 = new lib.CachedTexturedBitmap_43();
	this.instance_15.parent = this;
	this.instance_15.setTransform(103.55,-32,0.2125,0.2125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// marks_top
	this.instance_16 = new lib.CachedTexturedBitmap_59();
	this.instance_16.parent = this;
	this.instance_16.setTransform(0.55,-50.2,0.2125,0.2125);

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(1));

	// marks_bottom
	this.instance_17 = new lib.CachedTexturedBitmap_60();
	this.instance_17.parent = this;
	this.instance_17.setTransform(0.55,-15.2,0.2125,0.2125);

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(1));

	// Vertical_Lines
	this.instance_18 = new lib.CachedTexturedBitmap_61();
	this.instance_18.parent = this;
	this.instance_18.setTransform(-0.1,-50.2,0.2125,0.2125);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(1));

	// Horizontal_Lines
	this.instance_19 = new lib.CachedTexturedBitmap_62();
	this.instance_19.parent = this;
	this.instance_19.setTransform(-0.2,-50.25,0.2125,0.2125);

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(1));

	// Layer_14
	this.instance_20 = new lib.CachedTexturedBitmap_63();
	this.instance_20.parent = this;
	this.instance_20.setTransform(77.15,-50.15,0.2125,0.2125);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(1));

	// Layer_13
	this.instance_21 = new lib.CachedTexturedBitmap_64();
	this.instance_21.parent = this;
	this.instance_21.setTransform(154.2,-50.2,0.2125,0.2125);

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(1));

}).prototype = getMCSymbolPrototype(lib.ruler_sb, new cjs.Rectangle(-1.9,-50.2,235.1,50.7), null);


(lib.rainbow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.CachedTexturedBitmap_41();
	this.instance.parent = this;
	this.instance.setTransform(0.3,0.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.CachedTexturedBitmap_42();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.rainbow, new cjs.Rectangle(0,0,520,121.8), null);


(lib.buttn_Zn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Zn", "40px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 45;
	this.text.lineWidth = 51;
	this.text.parent = this;
	this.text.setTransform(1.3,-21.8);

	this.instance = new lib.image9();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,80,76);


(lib.buttn_Sr = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Sr", "40px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 45;
	this.text.lineWidth = 51;
	this.text.parent = this;
	this.text.setTransform(1.3,-21.8);

	this.instance = new lib.image9();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,80,76);


(lib.buttn_Si = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Si", "45px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 50;
	this.text.lineWidth = 51;
	this.text.parent = this;
	this.text.setTransform(0.3,-21.8);

	this.instance = new lib.image25();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image29();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,80,75);


(lib.buttn_S = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("S", "45px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 50;
	this.text.lineWidth = 33;
	this.text.parent = this;
	this.text.setTransform(-0.1,-23.05);

	this.instance = new lib.image18();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image22();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,78,75);


(lib.buttn_Pb = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Pb", "40px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 45;
	this.text.lineWidth = 51;
	this.text.parent = this;
	this.text.setTransform(1.3,-21.8);

	this.instance = new lib.image9();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,80,76);


(lib.buttn_P = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("P", "45px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 50;
	this.text.lineWidth = 33;
	this.text.parent = this;
	this.text.setTransform(-0.1,-23.05);

	this.instance = new lib.image18();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image22();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,78,75);


(lib.buttn_O = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("O", "46px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 51;
	this.text.lineWidth = 36;
	this.text.parent = this;
	this.text.setTransform(1.2,-23.05);

	this.instance = new lib.image18();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image22();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,78,75);


(lib.buttn_Ni = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Ni", "40px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 45;
	this.text.lineWidth = 51;
	this.text.parent = this;
	this.text.setTransform(1.3,-21.8);

	this.instance = new lib.image9();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,80,76);


(lib.buttn_Ne = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Ne", "40px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 45;
	this.text.lineWidth = 51;
	this.text.parent = this;
	this.text.setTransform(1.3,-21.8);

	this.instance = new lib.image18();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image22();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,78,75);


(lib.buttn_Na = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Na", "40px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 45;
	this.text.lineWidth = 51;
	this.text.parent = this;
	this.text.setTransform(1.3,-21.8);

	this.instance = new lib.image9();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,80,76);


(lib.buttn_N = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("N", "46px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 51;
	this.text.lineWidth = 33;
	this.text.parent = this;
	this.text.setTransform(-0.1,-23.05);

	this.instance = new lib.image18();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image22();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,78,75);


(lib.buttn_Mg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Mg", "34px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 38;
	this.text.lineWidth = 54;
	this.text.parent = this;
	this.text.setTransform(1.5,-18.25);

	this.instance = new lib.image9();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,80,76);


(lib.buttn_Li = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Li", "40px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 45;
	this.text.lineWidth = 51;
	this.text.parent = this;
	this.text.setTransform(1.3,-21.8);

	this.instance = new lib.image9();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,80,76);


(lib.buttn_K = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("K", "45px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 50;
	this.text.lineWidth = 51;
	this.text.parent = this;
	this.text.setTransform(1.3,-21.8);

	this.instance = new lib.image9();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,80,76);


(lib.buttn_He = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("He", "40px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 45;
	this.text.lineWidth = 51;
	this.text.parent = this;
	this.text.setTransform(1.3,-21.8);

	this.instance = new lib.image18();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image22();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,78,75);


(lib.buttn_H = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("H", "46px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 51;
	this.text.lineWidth = 33;
	this.text.parent = this;
	this.text.setTransform(-0.1,-23.05);

	this.instance = new lib.image18();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image22();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,78,75);


(lib.buttn_F = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("F", "46px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 51;
	this.text.lineWidth = 36;
	this.text.parent = this;
	this.text.setTransform(1.2,-23.05);

	this.instance = new lib.image18();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image22();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,78,75);


(lib.buttn_Cl = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Cl", "40px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 45;
	this.text.lineWidth = 40;
	this.text.parent = this;
	this.text.setTransform(0.5,-24.15);

	this.instance = new lib.image18();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image22();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,78,75);


(lib.buttn_Ca = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Ca", "40px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 45;
	this.text.lineWidth = 51;
	this.text.parent = this;
	this.text.setTransform(1.3,-21.8);

	this.instance = new lib.image9();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,80,76);


(lib.buttn_C = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("C", "46px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 51;
	this.text.lineWidth = 33;
	this.text.parent = this;
	this.text.setTransform(-0.1,-23.05);

	this.instance = new lib.image18();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image22();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,78,75);


(lib.buttn_Be = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Be", "40px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 45;
	this.text.lineWidth = 51;
	this.text.parent = this;
	this.text.setTransform(1.3,-21.8);

	this.instance = new lib.image9();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,80,76);


(lib.buttn_B = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("B", "45px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 50;
	this.text.lineWidth = 51;
	this.text.parent = this;
	this.text.setTransform(0.3,-24.8);

	this.instance = new lib.image25();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image29();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,80,75);


(lib.buttn_Ar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Ar", "40px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 45;
	this.text.lineWidth = 52;
	this.text.parent = this;
	this.text.setTransform(0.2,-21.15);

	this.instance = new lib.image18();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image22();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,78,75);


(lib.buttn_Al = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Al", "40px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 45;
	this.text.lineWidth = 51;
	this.text.parent = this;
	this.text.setTransform(1.3,-21.8);

	this.instance = new lib.image9();
	this.instance.parent = this;
	this.instance.setTransform(-39,-38);

	this.instance_1 = new lib.image13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]}).to({state:[{t:this.instance_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.instance},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-38,80,76);


(lib.zinc_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.Zn();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4902,0.9001);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.zinc_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.zinc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.zinc_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.zinc, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.sulfur_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.S();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4896,0.9001);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.sulfur_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.sulfur = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.sulfur_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.sulfur, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.strontium_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.Sr();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4902,0.9001);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.strontium_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.strontium = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.strontium_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.strontium, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.sodium_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.Na();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4889,0.9001);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.sodium_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.sodium = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.sodium_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.sodium, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.silicon_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.Si();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4902,0.9001);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.silicon_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.silicon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.silicon_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.silicon, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.potassium_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.K();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4902,0.9183);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.potassium_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.potassium = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.potassium_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.potassium, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.phosphorus_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.P();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4889,0.8821);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.phosphorus_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.phosphorus = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.phosphorus_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.phosphorus, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.oxygen_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.O();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4889,0.9091);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.oxygen_sp, new cjs.Rectangle(-0.3,-0.3,375.7,91.2), null);


(lib.oxygen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.oxygen_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.oxygen, new cjs.Rectangle(-0.3,-0.3,375.7,91.2), null);


(lib.nitrogen_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.N();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4889,0.9091);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.nitrogen_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.nitrogen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.nitrogen_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.nitrogen, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.nickel_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.Ni();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4889,0.9091);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.nickel_sp, new cjs.Rectangle(-0.3,-0.3,375.7,91.2), null);


(lib.nickel = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.nickel_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.nickel, new cjs.Rectangle(-0.3,-0.3,375.7,91.2), null);


(lib.neon_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.Ne();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4889,0.9091);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.neon_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.neon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.neon_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.neon, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.movable_ruler_sb = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ruler
	this.h1 = new lib.yellowHandle_sb();
	this.h1.name = "h1";
	this.h1.parent = this;
	this.h1.setTransform(0,-31.2,1.653,1.0575);

	this.instance = new lib.ruler_sb();
	this.instance.parent = this;
	this.instance.setTransform(-112.4,25,0.9986,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.h1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.movable_ruler_sb, new cjs.Rectangle(-114.3,-34.8,234.8,60.3), null);


(lib.magnesium_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.Mg();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4902,0.9183);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.magnesium_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.magnesium = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.magnesium_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.magnesium, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.lithium_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.Li();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4902,0.9474);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.lithium_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.lithium = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.lithium_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.lithium, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.lead_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.Pb();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4902,0.8821);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.lead_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.lead = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.lead_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.lead, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.hydrogen_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.H();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4915,0.9091);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.hydrogen_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.hydrogen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// hydrogen_s
	this.instance = new lib.hydrogen_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.hydrogen, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.helium_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.He();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4896,0.9001);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.helium_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.helium = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.helium_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.helium, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.fluorine_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.F();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4896,0.9001);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.fluorine_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.fluorine = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.fluorine_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.fluorine, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.chlorine_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.Cl();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4896,0.9001);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.chlorine_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.chlorine = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.chlorine_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.chlorine, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.carbon_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.C();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4889,0.9091);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.carbon_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.carbon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.carbon_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.carbon, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.calcium_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.Ca();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4902,0.9001);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.calcium_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.calcium = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.calcium_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.calcium, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.boron_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.B();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3627,0.6522);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.boron_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.boron = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.boron_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.boron, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.berylium_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.Be();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4915,0.9001);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.berylium_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.berylium = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.berylium_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.berylium, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.argon_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.Ar();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4896,0.9001);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.argon_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.argon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.argon_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.argon, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.aluminum_sp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// spectra
	this.instance_1 = new lib.Al();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.4896,0.9001);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// transparent
	this.instance_2 = new lib.transparent();
	this.instance_2.parent = this;
	this.instance_2.setTransform(187.5,45,1,1,0,0,0,187.5,45);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.aluminum_sp, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


(lib.aluminum = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// spect
	this.instance = new lib.aluminum_sp();
	this.instance.parent = this;
	this.instance.setTransform(187.5,45,1,1,0,0,0,187.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// back
	this.instance_1 = new lib.CachedTexturedBitmap_75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.35,-0.35,0.3606,0.3606);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.aluminum, new cjs.Rectangle(-0.3,-0.3,375.7,90.8), null);


// stage content:
(lib.emission = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		createjs.Touch.enable(stage);
		
		this.ruler.on("pressmove", function(evt){
		    var p = stage.globalToLocal(evt.stageX, evt.stageY);
		    evt.currentTarget.x = p.x;
		    evt.currentTarget.y = p.y + 71.10;
		});
		
		
		this.H_bttn.addEventListener("click", fl_ClickToHide_1.bind(this));
		
		function fl_ClickToHide_1()
		{
		    this.Symb.text = "Hydrogen";
			this.Lines.text = "656.3, 486.1, 434.0, 410.2"; 
			
			this.s1.visible = true;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.He_buttn.addEventListener("click", fl_ClickToHide_2.bind(this));
		
		function fl_ClickToHide_2()
		{
			this.Symb.text = "Helium";
			this.Lines.text = "587.5, 447.1, 501.5, 667.8"; 
			
			this.s1.visible = false;
			this.s2.visible = true;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.Li_buttn.addEventListener("click", fl_ClickToHide_3.bind(this));
		
		function fl_ClickToHide_3()
		{
			this.Symb.text = "Lithium";
			this.Lines.text = "670.8, 610.3, 413.2, 427.3"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = true;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.Be_buttn.addEventListener("click", fl_ClickToHide_4.bind(this));
		
		function fl_ClickToHide_4()
		{
			this.Symb.text = "Berylium";
			this.Lines.text = "467.3, 436.1, 527.0, 440.7"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = true;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.B_buttn.addEventListener("click", fl_ClickToHide_5.bind(this));
		
		function fl_ClickToHide_5()
		{
			this.Symb.text = "Boron";
			this.Lines.text = "449.8, 412.1, 448.7, 494.0"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = true;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.C_buttn.addEventListener("click", fl_ClickToHide_6.bind(this));
		
		function fl_ClickToHide_6()
		{
			this.Symb.text = "Carbon";
			this.Lines.text = "426.7, 657.8, 464.7, 514.5"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = true;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.N_buttn.addEventListener("click", fl_ClickToHide_7.bind(this));
		
		function fl_ClickToHide_7()
		{
			this.Symb.text = "Nitrogen";
			this.Lines.text = "463.0, 567.9, 500.5, 661.0"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = true;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.O_buttn.addEventListener("click", fl_ClickToHide_8.bind(this));
		
		function fl_ClickToHide_8()
		{   
			this.Symb.text = "Oxygen";
			this.Lines.text = "441.5, 419.0, 407.5, 615.7"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = true;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		
		this.F_buttn.addEventListener("click", fl_ClickToHide_9.bind(this));
		
		function fl_ClickToHide_9()
		{
			this.Symb.text = "Fluorine";
			this.Lines.text = "685.6, 690.2, 624.0, 634.8"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = true;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.Ne_buttn.addEventListener("click", fl_ClickToHide_10.bind(this));
		
		function fl_ClickToHide_10()
		{
			this.Symb.text = "Neon";
			this.Lines.text = "640.2, 621.7, 626.6, 659.9"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = true;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		
		this.Na_buttn.addEventListener("click", fl_ClickToHide_11.bind(this));
		
		function fl_ClickToHide_11()
		{
			this.Symb.text = "Sodium";
			this.Lines.text = "588.9, 412.3, 423.3, 439.2"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = true;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.Mg_buttn.addEventListener("click", fl_ClickToHide_12.bind(this));
		
		function fl_ClickToHide_12()
		{
			this.Symb.text = "Magnesium";
			this.Lines.text = "518.3, 516.7, 571.1, 450.1"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = true;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.Al_buttn.addEventListener("click", fl_ClickToHide_13.bind(this));
		
		function fl_ClickToHide_13()
		{
			this.Symb.text = "Aluminum";
			this.Lines.text = "572.3, 452.9, 415.0, 448.0"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = true;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.Si_buttn.addEventListener("click", fl_ClickToHide_14.bind(this));
		
		function fl_ClickToHide_14()
		{
			this.Symb.text = "Silicon";
			this.Lines.text = "637.1, 634.7, 567.0, 505.6"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = true;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.P_buttn.addEventListener("click", fl_ClickToHide_15.bind(this));
		
		function fl_ClickToHide_15()
		{
			this.Symb.text = "Phosphorus";
			this.Lines.text = "650.3, 646.0, 458.8, 422.2"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = true;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.S_buttn.addEventListener("click", fl_ClickToHide_16.bind(this));
		
		function fl_ClickToHide_16()
		{
			this.Symb.text = "Sulfur";
			this.Lines.text = "560.6, 547.4, 550.9, 545.4"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = true;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.Cl_buttn.addEventListener("click", fl_ClickToHide_17.bind(this));
		
		function fl_ClickToHide_17()
		{
			this.Symb.text = "Chlorine";
			this.Lines.text = "479.4, 542.3, 489.6, 521.8"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = true;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.Ar_buttn.addEventListener("click", fl_ClickToHide_18.bind(this));
		
		function fl_ClickToHide_18()
		{
			this.Symb.text = "Argon";
			this.Lines.text = "696.5, 488.0, 476.4, 434.8"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = true;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.K_buttn.addEventListener("click", fl_ClickToHide_19.bind(this));
		
		function fl_ClickToHide_19()
		{
			this.Symb.text = "Potassium";
			this.Lines.text = "693.8, 691.1, 404.4, 580.1"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = true;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.Ca_buttn.addEventListener("click", fl_ClickToHide_20.bind(this));
		
		function fl_ClickToHide_20()
		{
			this.Symb.text = "Calcium";
			this.Lines.text = "645.7, 502.0, 500.1, 530.7"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = true;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.Sr_buttn.addEventListener("click", fl_ClickToHide_21.bind(this));
		
		function fl_ClickToHide_21()
		{
			this.Symb.text = "Strontium";
			this.Lines.text = "460.7, 407.7, 421.5, 640.8"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = true;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.Ni_buttn.addEventListener("click", fl_ClickToHide_22.bind(this));
		
		function fl_ClickToHide_22()
		{
			this.Symb.text = "Nickel";
			this.Lines.text = "499.2, 547.7, 471.4, 490.1"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = true;
			this.s23.visible = false;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		this.Zn_buttn.addEventListener("click", fl_ClickToHide_23.bind(this));
		
		function fl_ClickToHide_23()
		{
			this.Symb.text = "Zinc";
			this.Lines.text = "491.1, 589.4, 602.1, 610.2"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = true;
			this.s24.visible = false;
			this.rb.visible = false;
		}
		
		
		this.Pb_buttn.addEventListener("click", fl_ClickToHide_24.bind(this));
		
		function fl_ClickToHide_24()
		{
			this.Symb.text = "Lead";
			this.Lines.text = "405.7, 401.9, 416.8, 600.2"; 
			
			this.s1.visible = false;
			this.s2.visible = false;
			this.s3.visible = false;
			this.s4.visible = false;
			this.s5.visible = false;
			this.s6.visible = false;
			this.s7.visible = false;
			this.s8.visible = false;
			this.s9.visible = false;
			this.s10.visible = false;
			this.s11.visible = false;
			this.s12.visible = false;
			this.s13.visible = false;
			this.s14.visible = false;
			this.s15.visible = false;
			this.s16.visible = false;
			this.s17.visible = false;
			this.s18.visible = false;
			this.s19.visible = false;
			this.s20.visible = false;
			this.s21.visible = false;
			this.s22.visible = false;
			this.s23.visible = false;
			this.s24.visible = true;
			this.rb.visible = false;
		}
		this.s1.visible = false;
		this.s2.visible = false;
		this.s3.visible = false;
		this.s4.visible = false;
		this.s5.visible = false;
		this.s6.visible = false;
		this.s7.visible = false;
		this.s8.visible = false;
		this.s9.visible = false;
		this.s10.visible = false;
		this.s11.visible = false;
		this.s12.visible = false;
		this.s13.visible = false;
		this.s14.visible = false;
		this.s15.visible = false;
		this.s16.visible = false;
		this.s17.visible = false;
		this.s18.visible = false;
		this.s19.visible = false;
		this.s20.visible = false;
		this.s21.visible = false;
		this.s22.visible = false;
		this.s23.visible = false;
		this.s24.visible = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Buttons
	this.Pb_buttn = new lib.buttn_Pb();
	this.Pb_buttn.name = "Pb_buttn";
	this.Pb_buttn.parent = this;
	this.Pb_buttn.setTransform(228.6,131.45,0.3846,0.384,0,0,0,0,0.1);
	new cjs.ButtonHelper(this.Pb_buttn, 0, 1, 2);

	this.Zn_buttn = new lib.buttn_Zn();
	this.Zn_buttn.name = "Zn_buttn";
	this.Zn_buttn.parent = this;
	this.Zn_buttn.setTransform(155.05,127.25,0.3846,0.384);
	new cjs.ButtonHelper(this.Zn_buttn, 0, 1, 2);

	this.Sr_buttn = new lib.buttn_Sr();
	this.Sr_buttn.name = "Sr_buttn";
	this.Sr_buttn.parent = this;
	this.Sr_buttn.setTransform(71,156.1,0.3846,0.384,0,0,0,0,0.1);
	new cjs.ButtonHelper(this.Sr_buttn, 0, 1, 2);

	this.Ni_buttn = new lib.buttn_Ni();
	this.Ni_buttn.name = "Ni_buttn";
	this.Ni_buttn.parent = this;
	this.Ni_buttn.setTransform(114.05,127.3,0.3846,0.384,0,0,0,0.1,0.1);
	new cjs.ButtonHelper(this.Ni_buttn, 0, 1, 2);

	this.Ar_buttn = new lib.buttn_Ar();
	this.Ar_buttn.name = "Ar_buttn";
	this.Ar_buttn.parent = this;
	this.Ar_buttn.setTransform(348.65,98.5,0.3846,0.384,0,0,0,0,0.1);
	new cjs.ButtonHelper(this.Ar_buttn, 0, 1, 2);

	this.Cl_buttn = new lib.buttn_Cl();
	this.Cl_buttn.name = "Cl_buttn";
	this.Cl_buttn.parent = this;
	this.Cl_buttn.setTransform(318.6,98.45,0.3846,0.384);
	new cjs.ButtonHelper(this.Cl_buttn, 0, 1, 2);

	this.S_buttn = new lib.buttn_S();
	this.S_buttn.name = "S_buttn";
	this.S_buttn.parent = this;
	this.S_buttn.setTransform(288.65,98.5,0.3846,0.384,0,0,0,0.1,0.1);
	new cjs.ButtonHelper(this.S_buttn, 0, 1, 2);

	this.P_buttn = new lib.buttn_P();
	this.P_buttn.name = "P_buttn";
	this.P_buttn.parent = this;
	this.P_buttn.setTransform(258.65,98.5,0.3846,0.384,0,0,0,0.1,0.1);
	new cjs.ButtonHelper(this.P_buttn, 0, 1, 2);

	this.Si_buttn = new lib.buttn_Si();
	this.Si_buttn.name = "Si_buttn";
	this.Si_buttn.parent = this;
	this.Si_buttn.setTransform(228.65,98.5,0.3846,0.384,0,0,0,0.1,0.1);
	new cjs.ButtonHelper(this.Si_buttn, 0, 1, 2);

	this.Al_buttn = new lib.buttn_Al();
	this.Al_buttn.name = "Al_buttn";
	this.Al_buttn.parent = this;
	this.Al_buttn.setTransform(198.65,98.5,0.3846,0.384,0,0,0,0.1,0.1);
	new cjs.ButtonHelper(this.Al_buttn, 0, 1, 2);

	this.Ca_buttn = new lib.buttn_Ca();
	this.Ca_buttn.name = "Ca_buttn";
	this.Ca_buttn.parent = this;
	this.Ca_buttn.setTransform(71,127.3,0.3846,0.384,0,0,0,0,0.1);
	new cjs.ButtonHelper(this.Ca_buttn, 0, 1, 2);

	this.K_buttn = new lib.buttn_K();
	this.K_buttn.name = "K_buttn";
	this.K_buttn.parent = this;
	this.K_buttn.setTransform(41.05,127.25,0.3846,0.384,0,0,0,0.1,0);
	new cjs.ButtonHelper(this.K_buttn, 0, 1, 2);

	this.Mg_buttn = new lib.buttn_Mg();
	this.Mg_buttn.name = "Mg_buttn";
	this.Mg_buttn.parent = this;
	this.Mg_buttn.setTransform(71.05,98.45,0.3846,0.384,0,0,0,0.1,0);
	new cjs.ButtonHelper(this.Mg_buttn, 0, 1, 2);

	this.Na_buttn = new lib.buttn_Na();
	this.Na_buttn.name = "Na_buttn";
	this.Na_buttn.parent = this;
	this.Na_buttn.setTransform(41.05,98.45,0.3846,0.384,0,0,0,0.1,0);
	new cjs.ButtonHelper(this.Na_buttn, 0, 1, 2);

	this.Ne_buttn = new lib.buttn_Ne();
	this.Ne_buttn.name = "Ne_buttn";
	this.Ne_buttn.parent = this;
	this.Ne_buttn.setTransform(348.7,69.7,0.3846,0.384,0,0,0,0.1,0.1);
	new cjs.ButtonHelper(this.Ne_buttn, 0, 1, 2);

	this.F_buttn = new lib.buttn_F();
	this.F_buttn.name = "F_buttn";
	this.F_buttn.parent = this;
	this.F_buttn.setTransform(318.65,69.7,0.3846,0.384,0,0,0,0.1,0.1);
	new cjs.ButtonHelper(this.F_buttn, 0, 1, 2);

	this.O_buttn = new lib.buttn_O();
	this.O_buttn.name = "O_buttn";
	this.O_buttn.parent = this;
	this.O_buttn.setTransform(288.65,69.7,0.3846,0.384,0,0,0,0.1,0.1);
	new cjs.ButtonHelper(this.O_buttn, 0, 1, 2);

	this.N_buttn = new lib.buttn_N();
	this.N_buttn.name = "N_buttn";
	this.N_buttn.parent = this;
	this.N_buttn.setTransform(258.6,69.7,0.3846,0.384,0,0,0,0,0.1);
	new cjs.ButtonHelper(this.N_buttn, 0, 1, 2);

	this.C_buttn = new lib.buttn_C();
	this.C_buttn.name = "C_buttn";
	this.C_buttn.parent = this;
	this.C_buttn.setTransform(228.6,69.65,0.3846,0.384);
	new cjs.ButtonHelper(this.C_buttn, 0, 1, 2);

	this.B_buttn = new lib.buttn_B();
	this.B_buttn.name = "B_buttn";
	this.B_buttn.parent = this;
	this.B_buttn.setTransform(198.65,69.7,0.3846,0.384,0,0,0,0.1,0.1);
	new cjs.ButtonHelper(this.B_buttn, 0, 1, 2);

	this.Be_buttn = new lib.buttn_Be();
	this.Be_buttn.name = "Be_buttn";
	this.Be_buttn.parent = this;
	this.Be_buttn.setTransform(71.05,69.65,0.3846,0.384,0,0,0,0.1,0);
	new cjs.ButtonHelper(this.Be_buttn, 0, 1, 2);

	this.Li_buttn = new lib.buttn_Li();
	this.Li_buttn.name = "Li_buttn";
	this.Li_buttn.parent = this;
	this.Li_buttn.setTransform(41,69.65,0.3846,0.384);
	new cjs.ButtonHelper(this.Li_buttn, 0, 1, 2);

	this.He_buttn = new lib.buttn_He();
	this.He_buttn.name = "He_buttn";
	this.He_buttn.parent = this;
	this.He_buttn.setTransform(348.65,40.85,0.3846,0.3844);
	new cjs.ButtonHelper(this.He_buttn, 0, 1, 2);

	this.H_bttn = new lib.buttn_H();
	this.H_bttn.name = "H_bttn";
	this.H_bttn.parent = this;
	this.H_bttn.setTransform(41.05,40.95,0.3846,0.384,0,0,0,0.1,0.3);
	new cjs.ButtonHelper(this.H_bttn, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.H_bttn},{t:this.He_buttn},{t:this.Li_buttn},{t:this.Be_buttn},{t:this.B_buttn},{t:this.C_buttn},{t:this.N_buttn},{t:this.O_buttn},{t:this.F_buttn},{t:this.Ne_buttn},{t:this.Na_buttn},{t:this.Mg_buttn},{t:this.K_buttn},{t:this.Ca_buttn},{t:this.Al_buttn},{t:this.Si_buttn},{t:this.P_buttn},{t:this.S_buttn},{t:this.Cl_buttn},{t:this.Ar_buttn},{t:this.Ni_buttn},{t:this.Sr_buttn},{t:this.Zn_buttn},{t:this.Pb_buttn}]}).wait(1));

	// Ruler
	this.ruler = new lib.movable_ruler_sb();
	this.ruler.name = "ruler";
	this.ruler.parent = this;
	this.ruler.setTransform(312.55,264.1,2.2401,2.3528,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.ruler).wait(1));

	// H
	this.s1 = new lib.hydrogen();
	this.s1.name = "s1";
	this.s1.parent = this;
	this.s1.setTransform(320.4,395.55,1.3866,1.3332,0,0,0,187.8,45.4);

	this.timeline.addTween(cjs.Tween.get(this.s1).wait(1));

	// He
	this.s2 = new lib.helium();
	this.s2.name = "s2";
	this.s2.parent = this;
	this.s2.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s2).wait(1));

	// Li
	this.s3 = new lib.lithium();
	this.s3.name = "s3";
	this.s3.parent = this;
	this.s3.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s3).wait(1));

	// Be
	this.s4 = new lib.berylium();
	this.s4.name = "s4";
	this.s4.parent = this;
	this.s4.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s4).wait(1));

	// B
	this.s5 = new lib.boron();
	this.s5.name = "s5";
	this.s5.parent = this;
	this.s5.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s5).wait(1));

	// C
	this.s6 = new lib.carbon();
	this.s6.name = "s6";
	this.s6.parent = this;
	this.s6.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s6).wait(1));

	// N
	this.s7 = new lib.nitrogen();
	this.s7.name = "s7";
	this.s7.parent = this;
	this.s7.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s7).wait(1));

	// O
	this.s8 = new lib.oxygen();
	this.s8.name = "s8";
	this.s8.parent = this;
	this.s8.setTransform(320.4,394.5,1.3867,1.3201,0,0,0,187.8,45.1);

	this.timeline.addTween(cjs.Tween.get(this.s8).wait(1));

	// F
	this.s9 = new lib.fluorine();
	this.s9.name = "s9";
	this.s9.parent = this;
	this.s9.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s9).wait(1));

	// Ne
	this.s10 = new lib.neon();
	this.s10.name = "s10";
	this.s10.parent = this;
	this.s10.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s10).wait(1));

	// Na
	this.s11 = new lib.sodium();
	this.s11.name = "s11";
	this.s11.parent = this;
	this.s11.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s11).wait(1));

	// Mg
	this.s12 = new lib.magnesium();
	this.s12.name = "s12";
	this.s12.parent = this;
	this.s12.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s12).wait(1));

	// Al
	this.s13 = new lib.aluminum();
	this.s13.name = "s13";
	this.s13.parent = this;
	this.s13.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s13).wait(1));

	// Si
	this.s14 = new lib.silicon();
	this.s14.name = "s14";
	this.s14.parent = this;
	this.s14.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s14).wait(1));

	// P
	this.s15 = new lib.phosphorus();
	this.s15.name = "s15";
	this.s15.parent = this;
	this.s15.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s15).wait(1));

	// S
	this.s16 = new lib.sulfur();
	this.s16.name = "s16";
	this.s16.parent = this;
	this.s16.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s16).wait(1));

	// Cl
	this.s17 = new lib.chlorine();
	this.s17.name = "s17";
	this.s17.parent = this;
	this.s17.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s17).wait(1));

	// Ar
	this.s18 = new lib.argon();
	this.s18.name = "s18";
	this.s18.parent = this;
	this.s18.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s18).wait(1));

	// K
	this.s19 = new lib.potassium();
	this.s19.name = "s19";
	this.s19.parent = this;
	this.s19.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s19).wait(1));

	// Ca
	this.s20 = new lib.calcium();
	this.s20.name = "s20";
	this.s20.parent = this;
	this.s20.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s20).wait(1));

	// Sr
	this.s21 = new lib.strontium();
	this.s21.name = "s21";
	this.s21.parent = this;
	this.s21.setTransform(320.4,394.5,1.3867,1.3201,0,0,0,187.8,45.1);

	this.timeline.addTween(cjs.Tween.get(this.s21).wait(1));

	// Ni
	this.s22 = new lib.nickel();
	this.s22.name = "s22";
	this.s22.parent = this;
	this.s22.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s22).wait(1));

	// Zn
	this.s23 = new lib.zinc();
	this.s23.name = "s23";
	this.s23.parent = this;
	this.s23.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s23).wait(1));

	// Pb
	this.s24 = new lib.lead();
	this.s24.name = "s24";
	this.s24.parent = this;
	this.s24.setTransform(320.4,395,1.3867,1.3333,0,0,0,187.8,45);

	this.timeline.addTween(cjs.Tween.get(this.s24).wait(1));

	// Screen
	this.Lines = new cjs.Text("", "bold 20px 'Arial'");
	this.Lines.name = "Lines";
	this.Lines.textAlign = "center";
	this.Lines.lineHeight = 24;
	this.Lines.lineWidth = 189;
	this.Lines.parent = this;
	this.Lines.setTransform(504.55,101.95);

	this.Symb = new cjs.Text("", "bold 24px 'Arial'", "#CC6600");
	this.Symb.name = "Symb";
	this.Symb.textAlign = "center";
	this.Symb.lineHeight = 29;
	this.Symb.lineWidth = 139;
	this.Symb.parent = this;
	this.Symb.setTransform(502.5,63.05);

	this.instance = new lib.CachedTexturedBitmap_2();
	this.instance.parent = this;
	this.instance.setTransform(404.1,28.6,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(391.25,20.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance},{t:this.Symb},{t:this.Lines}]}).wait(1));

	// Rainbow
	this.rb = new lib.rainbow();
	this.rb.name = "rb";
	this.rb.parent = this;
	this.rb.setTransform(320,395,1,1,0,0,0,260,60);

	this.timeline.addTween(cjs.Tween.get(this.rb).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(346,260.3,270.79999999999995,196.5);
// library properties:
lib.properties = {
	id: '47502F13D3D94A42949D18B4BCF435E6',
	width: 640,
	height: 480,
	fps: 24,
	color: "#E2C68B",
	opacity: 1.00,
	manifest: [
		{src:"images/emission_atlas_.png?1571178261412", id:"emission_atlas_"},
		{src:"images/emission_atlas_2.png?1571178261414", id:"emission_atlas_2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['47502F13D3D94A42949D18B4BCF435E6'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;